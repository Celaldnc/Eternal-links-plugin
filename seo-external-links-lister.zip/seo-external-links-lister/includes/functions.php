<?php

function sell_list_external_links() {
    global $wpdb;
    $per_page = 100;
    $paged = isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
    $offset = ( $paged - 1 ) * $per_page;

    if (isset($_POST['sell_rescan'])) {
        delete_transient('sell_external_links');
    }

    $external_links = get_transient('sell_external_links');

    if ($external_links === false) {
        $external_links = array();
        $query = new WP_Query(array(
            'post_type' => 'any',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ));

        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $post_id = get_the_ID();
                $post_title = get_the_title();
                $post_edit_link = get_edit_post_link( $post_id );
                $post_content = get_the_content();
                $matches = array();
                preg_match_all('/<a\s+href=["\'](https?:\/\/[^"\']+)["\']/', $post_content, $matches);
                if ( ! empty( $matches[1] ) ) {
                    foreach ( $matches[1] as $url ) {
                        if ( strpos( $url, home_url() ) === false ) {
                            $external_links[] = array(
                                'post_title' => $post_title,
                                'post_edit_link' => $post_edit_link,
                                'url' => $url,
                            );
                        }
                    }
                }
            }
            wp_reset_postdata();
        }

        set_transient('sell_external_links', $external_links, HOUR_IN_SECONDS);
    }

    $total_links = count( $external_links );
    $total_pages = ceil( $total_links / $per_page );
    $external_links = array_slice( $external_links, $offset, $per_page );

    if ( ! empty( $external_links ) ) {
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>Post Title</th><th>URL</th></tr></thead>';
        echo '<tbody>';
        foreach ( $external_links as $link ) {
            echo '<tr>';
            echo '<td><a href="' . esc_url( $link['post_edit_link'] ) . '" target="_blank">' . esc_html( $link['post_title'] ) . '</a></td>';
            echo '<td><a href="' . esc_url( $link['url'] ) . '" target="_blank">' . esc_html( $link['url'] ) . '</a></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';

        $page_links = paginate_links( array(
            'base'    => add_query_arg( 'paged', '%#%' ),
            'format'  => '',
            'current' => $paged,
            'total'   => $total_pages,
        ) );

        if ( $page_links ) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . $page_links . '</div></div>';
        }
    } else {
        echo '<p>No external links found.</p>';
    }
}
?>
