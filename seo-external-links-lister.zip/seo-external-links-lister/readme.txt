=== SEO External Links Lister ===
 
Contributors: turksem, celaldinc, tahirdinc
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: SEO, External Links, Link analysis, Link lister
Tested up to: 6.5
Stable tag: 22.9
Requires PHP: 7.2.5 


With this plugin, you can see all outbound links on your site. This simple but useful plugin allows you to view all the links within your posts. The plugin is developed by Turk SEM and is planned to be continuously updated. You can "Rescan" from the plugin page to recheck.

== Plugin Installation ==

If you are installing via WordPress.org, you can install the plugin on your system by saying install directly. If you are going to install it manually, you should follow these steps.

Click the "Install Plugin" button in the Add Plugin section.
Select the "seo-external-links-lister.zip" file from the Browse section and click install.
Activate the plugin.
Plugin Scan Time
After installing the plugin, click on the "external links" link on the left menu and the scan will start. If you have a lot of posts, it will take a while to open. So wait patiently for the plugin to scan all your posts.

== Developer ==

The plugin was developed by software engineer Celal Dinç from Türk SEM. For your questions and suggestions, you can write an e-mail to celal.dinc@turksem.com.